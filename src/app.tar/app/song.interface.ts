export default interface Song{
    id: string;
    songName: string;
    albumName: string;
    artistName: string;
    songDescriptio: string;
}