export var firebaseConfig = {
  apiKey: "AIzaSyBr7Oe3RkmkJ307OcnLpBhMKr-gdxaVUQY",
  authDomain: "third-booth-404404.firebaseapp.com",
  projectId: "third-booth-404404",
  storageBucket: "third-booth-404404.appspot.com",
  messagingSenderId: "938582197653",
  appId: "1:938582197653:web:cd191d3586f7418cc1629c"
};